import React, { Component } from 'react';

import { Input } from './InputComponent/Input.jsx';

class App extends Component{
    constructor(props) {
        super(props);
        this.state = {
            FormDataSet: [
                { DefaultValue: "Test", Type: "date", LabelText: "Date Input", LabelClass: "LabelClass", InputClass: "form-control newInputClass" },
                { DefaultValue: "Test", Type: "time", LabelText: "Time Input", LabelClass: "LabelClass", InputClass: "form-control newInputClass" },
                { DefaultValue: "Test", Type: "text" ,LabelText: "Single Line Text" },
                { DefaultValue: "Test", Type:"textarea", LabelText: "MultilineText" },
                { DefaultValue: "458d", Type: "Number", LabelText: "Number Input" },
                { DefaultValue: "45", Type: "range", LabelText: "Range Input", InputClass: "custom-range form-control" },
                { DefaultValue: "", Type: "file", LabelText: "List Attachment" },
                { DefaultValue: "458", Type: "Select", LabelText: "Dropdown List Item", Options: ['First','Second','Third'] },
                { DefaultValue: "458", Type: "Checkbox", Id: "Test1", LabelText: "Dropdown List Item", Options: ['Next','First','Second','Third'] },
                { DefaultValue: "458", Type: "Checkbox", Id: "Test2", LabelText: "Dropdown List Item", Options: ['Next','First','Second','Third'] },
                { DefaultValue: "458", Type: "Checkbox", Id: "Test3", LabelText: "Dropdown List Item", Options: ['Next','First','Second','Third'] }
            ],
            AdminMode: false
        };
        this.changeMode = this.changeMode.bind(this);
        this.removeInput = this.removeInput.bind(this);
        this.changeInput = this.changeInput.bind(this);
    }
    changeMode() {
        var reactHandler = this;
        reactHandler.setState(()=>({ AdminMode : ! reactHandler.state.AdminMode }));
    }
    removeInput(index,e) {
        var reactHandler = this;
        var newUpdatedDataSet = reactHandler.state.FormDataSet.filter((x,Index)=>index!==Index);
        reactHandler.setState({FormDataSet : newUpdatedDataSet});
    }
    changeInput(index,ColumnName,e) {
        var reactHandler = this;
        console.log(e.target.value,index,ColumnName);
        reactHandler.state.FormDataSet[index][ColumnName]=e.target.value;
        
        reactHandler.setState({ FormDataSet : reactHandler.state.FormDataSet });
    }
    render(){
      return(
        <div className="container">
            <button onClick={this.changeMode}>{this.state.AdminMode ? 'Admin View' : 'User View'}</button>
            {this.state.AdminMode ? 
                <div className="jumbotron">
                    <table className="table table-sm table-border">
                        <thead>
                            <tr>
                                <th>Remove</th>
                                <th>Id</th>
                                <th>Column Name</th>
                                <th>Type</th>
                                <th>Default Value</th>
                                <th>Label Class</th>
                                <th>Input Class</th>
                                <th>Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.FormDataSet.map((x,index)=>{
                                    return (
                                        <tr id={`DataSetRow${index}`}>
                                            <td onClick={this.removeInput.bind(this,index)}>
                                                Remove
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.LabelText && x.LabelText} 
                                                Type='Text'
                                                changeInput={this.changeInput}
                                                index={index}
                                                ColumnName='Id'
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.LabelText && x.LabelText} 
                                                Type='Text'
                                                changeInput={this.changeInput}
                                                index={index}
                                                ColumnName='LabelText'
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.Type && x.Type} 
                                                Type='select'
                                                Options = {['date','time','text','textarea','Number','range','file','Select','Checkbox']}
                                                
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.DefaultValue && x.DefaultValue} 
                                                Type='Text'
                                                changeInput={this.changeInput}
                                                index={index}
                                                ColumnName='DefaultValue'
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.LabelClass && x.LabelClass} 
                                                Type='Text'
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.InputClass && x.InputClass} 
                                                Type='Text'
                                            />
                                            </td>
                                            <td>
                                            <Input 
                                                DefaultValue={x.Options && x.Options} 
                                                Type='Text'
                                            />
                                            </td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </table>
                </div>
            : 
            <div className="jumbotron">
            
            {
                this.state.FormDataSet.map((x)=>{
                    return (
                        <Input 
                            DefaultValue={ x.DefaultValue && x.DefaultValue } 
                            Type={ x.Type && x.Type } 
                            LabelText={ x.LabelText &&x.LabelText } 
                            LabelClass={ x.LabelClass && x.LabelClass } 
                            InputClass={ x.InputClass && x.InputClass }
                            Options={ x.Options && x.Options }
                            Id={ x.Id && x.Id }
                        />
                    );
                })
            }
            </div>
        }
        </div>
      );
   }
}

export default App;