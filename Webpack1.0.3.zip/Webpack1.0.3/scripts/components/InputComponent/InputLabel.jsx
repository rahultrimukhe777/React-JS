import React, { Component } from 'react';
import PropTypes from 'prop-types'; 

export const InputLabel = (props) => {
    return (
        <div className="input-group-prepend">
            <span className="input-group-text" id="basic-addon3" >
                { props.LabelText }
            </span>
        </div> 
    );
}