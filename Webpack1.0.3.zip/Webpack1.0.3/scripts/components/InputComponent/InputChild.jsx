import React, { Component } from 'react';
import { InputLabel } from './InputLabel.jsx';

export const InputText = (props) => {
    return (
        <input 
            type = {props.Type} 
            className = {props.InputClass} 
            id = {props.Id} 
            aria-describedby = "basic-addon3" 
            defaultValue = {props.DefaultValue} 
            style = {{height: 'auto'}}
            onBlur = {props.changeInput && props.changeInput.bind(this,props.index,props.ColumnName)}
        />
    );
}

export const TextArea = (props) => {
    return ( <textarea className={props.InputClass} aria-label="With textarea"></textarea> );
}

export const Select = (props) => {
    return (
        <select className={props.InputClass} id={props.Id} defaultValue={props.DefaultValue}>
            <option>Select</option>
            {  props.Options.map((x)=><option>{x}</option> )}
        </select>
    );
}

export const CheckBox = (props) => {
    return(
        <div className=" form-control">
            {  props.Options.map((x,index)=>
                <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id={`${props.Id}${index}`} name={props.Id} />
                    <label className="custom-control-label" htmlFor={`${props.Id}${index}`}>{x}</label>
                </div>
            )}
        </div>       
    );
}

export const InputFile = (props) => {
    return(
        <div className="custom-file">
            <input type="file" className="custom-file-input" multiple={true} onChange={changeFileName.bind(this)} id={props.Id} name="filename" />
            <label className="custom-file-label" htmlFor="customFile">Choose file</label>
        </div>
    );
}

const changeFileName = (e) => {
    let FileName = '';
    [...$(e.target)[0].files].map((x,index)=>{
        index===0 ? FileName = x.name : FileName = FileName + " || " + x.name;
    });
    $(e.target).siblings(".custom-file-label").addClass("selected").html(FileName);
}