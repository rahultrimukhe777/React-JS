import React, { Component } from 'react';
import PropTypes from 'prop-types'; 

export default class Input extends Component{
    constructor(props) {
        super(props);
        this.state = {
        }
    }
    render(){
      const props = this.props;
      debugger;
      switch(props.propType.toLowerCase()) {
          case 'text':
            console.log('Input Type is text');
            return <InputGroup/>;
            break;
          case 'file':
            console.log('Input Type is File');
            return <InputGroup/>;
            break;
          case 'textwithlabel':
            return <InputGroup propWithLabel={true} propLabelText={props.LabelText}/>;
            console.log("TextWithLabel");
            break;
          default:
            return <InputGroup Type="Text"/>;
            console.log('No type Match');
      }
      
   }
}

Input.propTypes = {
    propType: PropTypes.string.isRequired,
    propDefaultValue: PropTypes.string,
    inputFieldClass: PropTypes.string,
    inputValueChange: PropTypes.func,
    textWithLableText : PropTypes.string
}

Input.defaultProps = {
    propDefaultValue : '',
    inputValueChange : function(e){ 
        console.log(e.target.value);
        return e;
    },
    inputFieldClass : 'form-control',
    textWithLableText: 'Default Label'
}

export const InputGroup = (props) => {
    console.log(props);
    return (
        <div>
            <div className="input-group mb-3">
                {props.propWithLabel && <div className="input-group-prepend">
                    <span className="input-group-text" id="basic-addon3">{props.propLabelText}</span>
                </div> }
                <input type="text" className="form-control" id="basic-url" aria-describedby="basic-addon3" />
            </div>
        </div>
    );
}

InputGroup.propTypes = {
    propWithLabel: PropTypes.string,
    propLabelText: PropTypes.string
}

export class InputGroupBackup extends React.Component {
    render () {
        return (
            <div>
                    <div className="input-group mb-3">
                        <div className="input-group-prepend">
                            <span className="input-group-text" id="basic-addon1">@</span>
                        </div>
                        <input type="text" className="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
                    </div>

                    <div className="input-group mb-3">
                        <input type="text" className="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                        <div className="input-group-append">
                            <span className="input-group-text" id="basic-addon2">@example.com</span>
                        </div>
                    </div>

                    <label htmlFor="basic-url">Your vanity URL</label>
                    <div className="input-group mb-3">
                        <div className="input-group-prepend">
                            <span className="input-group-text" id="basic-addon3">https://example.com/users/</span>
                        </div>
                        <input type="text" className="form-control" id="basic-url" aria-describedby="basic-addon3" />
                    </div>

                    <div className="input-group mb-3">
                        <div className="input-group-prepend">
                            <span className="input-group-text">$</span>
                        </div>
                        <input type="text" className="form-control" aria-label="Amount (to the nearest dollar)" />
                        <div className="input-group-append">
                            <span className="input-group-text">.00</span>
                        </div>
                    </div>

                    <div className="input-group">
                        <div className="input-group-prepend">
                            <span className="input-group-text">With textarea</span>
                        </div>
                        <textarea className="form-control" aria-label="With textarea"></textarea>
                    </div>
                </div>
        );
    }
}


