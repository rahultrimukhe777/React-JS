import React, { Component } from 'react';
import PropTypes from 'prop-types'; 
import { InputText, TextArea, InputFile, Select, CheckBox } from './InputChild.jsx';
import { InputLabel } from './InputLabel.jsx';

export const  Input = (props) => {
    return (
        <div className="input-group mb-3">
            { props.LabelText && <InputLabel LabelText={props.LabelText}/> }
            { SwitchCase(props) }
        </div>
    ); 
}

const SwitchCase = (props) =>{
    switch(props.Type.toLowerCase()) {
        case 'text':
        case 'date':
        case 'time':
        case 'range':
        case 'number':
            return ( <InputText {...props}/> );
            break;
        case 'textarea':
            return ( <TextArea {...props}/> );
            break;
        case 'file':
            return (<InputFile />);
            break;
        case 'select' :
            return (<Select {...props} />);
            break;
        case 'checkbox':
            return (<CheckBox {...props} />);
        default:
            return ( <div >No Input Found</div> );
            break; 
    }
}

Input.propTypes = {
    Id: PropTypes.string.isRequired,
    DefaultValue : PropTypes.string,
    PlaceHolder : PropTypes.string, 
    Type : PropTypes.string.isRequired, 
    LabelText : PropTypes.string, 
    LabelClass : PropTypes.string,  
    InputClass : PropTypes.string, 
    Change: PropTypes.func
}

Input.defaultProps = {
    DefaultValue : '',
    PlaceHolder : 'Please enter something',
    Type : 'text', 
    InputClass : 'form-control',
    Change : function(e){ 
        console.log(e.target.value);
        return e;
    }
}
